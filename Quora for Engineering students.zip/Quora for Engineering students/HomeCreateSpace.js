

export const SpaceData = [
  { img: "assets/Home/books.jpeg", title: "Books" },
  { img: "assets/Home/business.jpeg", title: "Business" },
  { img: "assets/Home/cooking.jpeg", title: "Cooking" },
  { img: "assets/Home/design.jpeg", title: "Design" },
  { img: "assets/Home/education.jpeg", title: "Education" },
  { img: "assets/Home/health.jpeg", title: "Health" },
  { img: "assets/Home/history.jpeg", title: "History" },
  { img: "assets/Home/mechanical.jpeg", title: "Mechanical Engineering" },
  { img: "assets/Home/technology.jpeg", title: "Technology" },
];