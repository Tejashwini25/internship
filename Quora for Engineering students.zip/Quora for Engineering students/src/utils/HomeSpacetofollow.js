

export const SpacetoFollowData = [
  {
    img: "assets/Home/anonimous.jpeg",
    title: "The anonymously writes",
    content: "If you want to experiaence something new, follow",
  },
  {
    img: "assets/Home/husbandandwives.jpeg",
    title: "Husbands and wives",
    content: "About husbands and wives(why you need to ...",
  },
  {
    img: "assets/Home/memes.jpeg",
    title: "Memes Are Life♥️",
    content: "Sarcasm😝 | Dank Memes😂 | Trolls🤡 | Comics😆 |...",
  },
  {
    img: "assets/Home/itconfessions.png",
    title: "IT Confessions",
    content: "Open Confession is Good For Soul",
  },
  {
    img: "assets/Home/communication.png",
    title: "Communication Skills",
    content: "Share your experience, tips & tricks to deal with people.",
  },
  {
    img: "assets/Home/factsandknowledge.png",
    title: "Daily facts and knowledge",
    content: "This is about a knowledge of everything",
  },
  {
    img: "assets/Home/womenzone.jpeg",
    title: "Womens zone",
    content: "CAREER /FASHION -LIFESTYLE /WOMENS...",
  },
  {
    img: "assets/Home/marriedlife.jpeg",
    title: "MARRIED LIFE - Lets Talk Facts",
    content: "Early days of Marriage (Vs) Later life/True love in...",
  },
  {
    img: "assets/Home/indianfamily.jpeg",
    title: "Indian family things",
    content: "In India, we find different types of joint families. We...",
  },
  {
    img: "assets/Home/lifestuff.jpeg",
    title: "Life's stuffs",
    content: "This space is about experiences of our life and...",
  },
];